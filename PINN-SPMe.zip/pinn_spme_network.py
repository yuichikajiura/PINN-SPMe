import numpy as np
import torch
import torch.nn as nn

import custom_lstm


class PINNSPMeNetwork(nn.Module):
    def __init__(self, cfg, p):
        super().__init__()
        self.cfg = cfg
        self.p = p

        self.state_sizes = [p.n_cs_n, p.n_ce, p.n_cs_p]
        self.min_values = [
            torch.zeros(p.n_cs_n),
            torch.full((p.n_ce,), p.ce_min),
            torch.zeros(p.n_cs_p),
        ]
        self.max_values = [
            torch.full((p.n_cs_n,), p.c_s_n_max),
            torch.full((p.n_ce,), p.ce_max),
            torch.full((p.n_cs_p,), p.c_s_p_max),
        ]

        self.blocks = nn.ModuleList()
        for state_size, max_value, min_value in zip(self.state_sizes, self.max_values, self.min_values):
            fc_layers = np.array(cfg['hidden_lstm'])
            for _ in range(cfg['layer_fc']):
                fc_layers = np.append(fc_layers, cfg['hidden_fc'])
            fc_layers = np.append(fc_layers, state_size)
            self.blocks.append(custom_lstm.CustomLSTM(cfg, fc_layers, p.input_size, max_value, min_value))

    def forward(self, u_seq):
        c_s_n, c_e, c_s_p = self.predict_blocks(u_seq)
        return self.pack_state(c_s_n, c_e, c_s_p)

    def predict_blocks(self, u_seq):
        outputs = [block(u_seq) for block in self.blocks]
        return outputs[0], outputs[1], outputs[2]

    @staticmethod
    def pack_state(c_s_n, c_e, c_s_p):
        return torch.cat([c_s_n, c_e, c_s_p], dim=-1)

    def unpack_state(self, x):
        n_end = self.p.n_cs_n
        e_end = n_end + self.p.n_ce
        if x.dim() == 2:
            return x[:, :n_end], x[:, n_end:e_end], x[:, e_end:]
        if x.dim() == 3:
            return x[:, :n_end, :], x[:, n_end:e_end, :], x[:, e_end:, :]
        raise ValueError('State tensor must be 2D or 3D.')