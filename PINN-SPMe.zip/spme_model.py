import math

import torch
import torch.nn as nn

from electrolyte_fvm import (
    electrolyte_activity,
    electrolyte_boundary_concentrations,
    electrolyte_conductivity,
    electrolyte_region_means,
    electrolyte_rhs,
)


def ref_potential_anode(theta):
    return (1.9793 * torch.exp(-39.3631 * theta)
            + 0.2482
            - 0.09069 * torch.tanh(29.8538 * (theta - 0.1234))
            - 0.04478 * torch.tanh(14.9159 * (theta - 0.2769))
            - 0.0205 * torch.tanh(30.4444 * (theta - 0.6103)))


def ref_potential_cathode(theta):
    return (-0.8090 * theta
            + 4.4875
            - 0.0428 * torch.tanh(18.5138 * (theta - 0.5542))
            - 17.7326 * torch.tanh(15.7890 * (theta - 0.3117))
            + 17.5842 * torch.tanh(15.9308 * (theta - 0.3120)))


class SolidDiffusionFDM(nn.Module):
    def __init__(self, n_r):
        super().__init__()
        self.n_r = n_r
        self.register_buffer('matA', self.calc_matA())
        self.register_buffer('matB', self.calc_matB())
        self.register_buffer('matC', self.calc_matC())
        self.register_buffer('matD', self.calc_matD())

    def calc_matA(self):
        return self.matM1() - self.matM2() @ torch.inverse(self.matN2()) @ self.matN1()

    def calc_matB(self):
        return self.matM2() @ torch.inverse(self.matN2()) @ self.matN3()

    def calc_matC(self):
        return -torch.inverse(self.matN2()) @ self.matN1()

    def calc_matD(self):
        return torch.inverse(self.matN2()) @ self.matN3()

    def matM1(self):
        mat = torch.zeros(self.n_r - 1, self.n_r - 1)
        for idx in range(self.n_r - 1):
            mat[idx, idx] = -2.0
            if idx >= 1:
                mat[idx, idx - 1] = idx / (idx + 1)
            if idx <= self.n_r - 3:
                mat[idx, idx + 1] = (idx + 2) / (idx + 1)
        return mat

    def matM2(self):
        mat = torch.zeros(self.n_r - 1, 2)
        mat[self.n_r - 2, 1] = self.n_r / (self.n_r - 1)
        return mat

    def matN1(self):
        mat = torch.zeros(2, self.n_r - 1)
        mat[0, 0] = 4.0
        mat[0, 1] = -1.0
        mat[1, self.n_r - 3] = 1.0
        mat[1, self.n_r - 2] = -4.0
        return mat

    @staticmethod
    def matN2():
        return torch.tensor([[-3.0, 0.0], [0.0, 3.0]])

    @staticmethod
    def matN3():
        return torch.tensor([[0.0], [1.0]])


class SPMeModel(nn.Module):
    def __init__(self, p, cfg):
        super().__init__()
        self.p = p
        self.cfg = cfg
        self.h = cfg.get('h', 1)
        self.integ_type = cfg.get('integ_type', 1)
        self.n_r = p.Nr
        self.delta_r_bar = 1 / self.n_r
        self.solid_model = SolidDiffusionFDM(self.n_r)
        self._update_solid_dynamics()

    def _beta_base(self, R_s, D_s, a_s, area, length):
        return 2 * self.delta_r_bar * R_s / (D_s * self.p.Faraday * a_s * area * length)

    def _alpha(self, D_s, R_s):
        return D_s / ((R_s * self.delta_r_bar) ** 2)

    def _update_solid_dynamics(self):
        alpha_n = self._alpha(self.p.D_s_n, self.p.R_s_n)
        alpha_p = self._alpha(self.p.D_s_p, self.p.R_s_p)
        beta_n = -self._beta_base(self.p.R_s_n, self.p.D_s_n, self.p.a_s_n, self.p.Area_n, self.p.L_n)
        beta_p = self._beta_base(self.p.R_s_p, self.p.D_s_p, self.p.a_s_p, self.p.Area_p, self.p.L_p)
        device = self.solid_model.matA.device
        dtype = self.solid_model.matA.dtype
        self.register_buffer('matAn', alpha_n * self.solid_model.matA.to(device=device, dtype=dtype), persistent=False)
        self.register_buffer('matBn', alpha_n * beta_n * self.solid_model.matB.to(device=device, dtype=dtype), persistent=False)
        self.register_buffer('matAp', alpha_p * self.solid_model.matA.to(device=device, dtype=dtype), persistent=False)
        self.register_buffer('matBp', alpha_p * beta_p * self.solid_model.matB.to(device=device, dtype=dtype), persistent=False)
        self.register_buffer('matDn', beta_n * self.solid_model.matD.to(device=device, dtype=dtype), persistent=False)
        self.register_buffer('matDp', beta_p * self.solid_model.matD.to(device=device, dtype=dtype), persistent=False)

    def initial_state(self, batch_size=1, device=None, dtype=torch.float32):
        device = device if device is not None else self.solid_model.matA.device
        c_s_n = torch.full((batch_size, self.p.n_cs_n), self.p.csn0, device=device, dtype=dtype)
        c_e = torch.full((batch_size, self.p.n_ce), self.p.c_e0, device=device, dtype=dtype)
        c_s_p = torch.full((batch_size, self.p.n_cs_p), self.p.csp0, device=device, dtype=dtype)
        return self.pack_state(c_s_n, c_e, c_s_p)

    def pack_state(self, c_s_n, c_e, c_s_p):
        return torch.cat([c_s_n, c_e, c_s_p], dim=1)

    def unpack_state(self, x):
        n_end = self.p.n_cs_n
        e_end = n_end + self.p.n_ce
        if x.dim() == 2:
            return x[:, :n_end], x[:, n_end:e_end], x[:, e_end:]
        if x.dim() == 3:
            return x[:, :n_end, :], x[:, n_end:e_end, :], x[:, e_end:, :]
        raise ValueError('State tensor must be 2D or 3D.')

    @staticmethod
    def _linear_rhs(x, current, matA, matB):
        return x @ matA.T + current @ matB.T

    def _linear_step(self, x, current, matA, matB):
        if self.integ_type == 0:
            k1 = self._linear_rhs(x, current, matA, matB)
            k2 = self._linear_rhs(x + 0.5 * self.h * k1, current, matA, matB)
            k3 = self._linear_rhs(x + 0.5 * self.h * k2, current, matA, matB)
            k4 = self._linear_rhs(x + self.h * k3, current, matA, matB)
            return x + self.h * (k1 / 6 + k2 / 3 + k3 / 3 + k4 / 6)
        return x + self.h * self._linear_rhs(x, current, matA, matB)

    def _electrolyte_step(self, c_e, jn, jp):
        if self.integ_type == 0:
            k1 = electrolyte_rhs(c_e, jn, jp, self.p)
            k2 = electrolyte_rhs(c_e + 0.5 * self.h * k1, jn, jp, self.p)
            k3 = electrolyte_rhs(c_e + 0.5 * self.h * k2, jn, jp, self.p)
            k4 = electrolyte_rhs(c_e + self.h * k3, jn, jp, self.p)
            return c_e + self.h * (k1 / 6 + k2 / 3 + k3 / 3 + k4 / 6)
        return c_e + self.h * electrolyte_rhs(c_e, jn, jp, self.p)

    def step(self, x, current):
        c_s_n, c_e, c_s_p = self.unpack_state(x)
        jn = current / (self.p.Faraday * self.p.a_s_n * self.p.Area_n * self.p.L_n)
        jp = -current / (self.p.Faraday * self.p.a_s_p * self.p.Area_p * self.p.L_p)
        c_s_n_next = self._linear_step(c_s_n, current, self.matAn, self.matBn)
        c_e_next = self._electrolyte_step(c_e, jn, jp)
        c_s_p_next = self._linear_step(c_s_p, current, self.matAp, self.matBp)
        return self.pack_state(c_s_n_next, c_e_next, c_s_p_next)

    def forward(self, x, current_seq, k=None):
        if k is None:
            k = current_seq.shape[1]
        x_all = torch.zeros(x.shape[0], x.shape[1], k, device=x.device, dtype=x.dtype)
        xk = x
        for step_idx in range(k):
            current = current_seq[:, step_idx:step_idx + 1]
            xk = self.step(xk, current)
            x_all[:, :, step_idx] = xk
        return x_all

    def calc_css_and_cs0(self, x, current):
        c_s_n, _, c_s_p = self.unpack_state(x)
        matC = self.solid_model.matC.to(device=x.device, dtype=x.dtype)
        cs_n = torch.zeros(x.shape[0], self.n_r + 1, device=x.device, dtype=x.dtype)
        cs_p = torch.zeros(x.shape[0], self.n_r + 1, device=x.device, dtype=x.dtype)
        cs0_n = matC[0, 0] * c_s_n[:, 0] + matC[0, 1] * c_s_n[:, 1]
        cs0_p = matC[0, 0] * c_s_p[:, 0] + matC[0, 1] * c_s_p[:, 1]
        css_n = matC[1, self.n_r - 3] * c_s_n[:, self.n_r - 3] + matC[1, self.n_r - 2] * c_s_n[:, self.n_r - 2] + self.matDn[1] * current.squeeze(-1)
        css_p = matC[1, self.n_r - 3] * c_s_p[:, self.n_r - 3] + matC[1, self.n_r - 2] * c_s_p[:, self.n_r - 2] + self.matDp[1] * current.squeeze(-1)
        cs_n[:, 0] = cs0_n
        cs_n[:, 1:-1] = c_s_n
        cs_n[:, -1] = css_n
        cs_p[:, 0] = cs0_p
        cs_p[:, 1:-1] = c_s_p
        cs_p[:, -1] = css_p
        return cs_n, cs_p

    def calc_css_and_cs0_seq(self, x_seq, current_seq):
        c_s_n, _, c_s_p = self.unpack_state(x_seq)
        matC = self.solid_model.matC.to(device=x_seq.device, dtype=x_seq.dtype)
        cs_n = torch.zeros(x_seq.shape[0], self.n_r + 1, x_seq.shape[2], device=x_seq.device, dtype=x_seq.dtype)
        cs_p = torch.zeros(x_seq.shape[0], self.n_r + 1, x_seq.shape[2], device=x_seq.device, dtype=x_seq.dtype)
        cs0_n = matC[0, 0] * c_s_n[:, 0, :] + matC[0, 1] * c_s_n[:, 1, :]
        cs0_p = matC[0, 0] * c_s_p[:, 0, :] + matC[0, 1] * c_s_p[:, 1, :]
        css_n = matC[1, self.n_r - 3] * c_s_n[:, self.n_r - 3, :] + matC[1, self.n_r - 2] * c_s_n[:, self.n_r - 2, :] + self.matDn[1] * current_seq
        css_p = matC[1, self.n_r - 3] * c_s_p[:, self.n_r - 3, :] + matC[1, self.n_r - 2] * c_s_p[:, self.n_r - 2, :] + self.matDp[1] * current_seq
        cs_n[:, 0, :] = cs0_n
        cs_n[:, 1:-1, :] = c_s_n
        cs_n[:, -1, :] = css_n
        cs_p[:, 0, :] = cs0_p
        cs_p[:, 1:-1, :] = c_s_p
        cs_p[:, -1, :] = css_p
        return cs_n, cs_p

    def calc_cs_bar(self, cs):
        if cs.dim() == 2:
            c_ave = torch.zeros(cs.shape[0], device=cs.device, dtype=cs.dtype)
            for idx in range(self.n_r):
                r_u = (idx + 1) / self.n_r
                r_l = idx / self.n_r
                c_ave = c_ave + (4 * math.pi / 3) * (r_u ** 3 - r_l ** 3) * 0.5 * (cs[:, idx] + cs[:, idx + 1])
            return c_ave / (4 * math.pi / 3)
        if cs.dim() == 3:
            c_ave = torch.zeros(cs.shape[0], cs.shape[2], device=cs.device, dtype=cs.dtype)
            for idx in range(self.n_r):
                r_u = (idx + 1) / self.n_r
                r_l = idx / self.n_r
                c_ave = c_ave + (4 * math.pi / 3) * (r_u ** 3 - r_l ** 3) * 0.5 * (cs[:, idx, :] + cs[:, idx + 1, :])
            return c_ave / (4 * math.pi / 3)
        raise ValueError('cs must be 2D or 3D.')

    def calc_solid_lithium(self, c_n, c_p):
        cs_bar_n = self.calc_cs_bar(c_n)
        cs_bar_p = self.calc_cs_bar(c_p)
        return cs_bar_n * self.p.epsilon_s_n * self.p.L_n * self.p.Area_n + cs_bar_p * self.p.epsilon_s_p * self.p.L_p * self.p.Area_p

    def _exchange_current_density(self, css, ce, k0, activation_energy):
        arrh = torch.exp(torch.as_tensor(activation_energy / self.p.R * (1 / self.p.T_ref - 1 / self.p.T_amb), dtype=css.dtype, device=css.device))
        return k0 * arrh * torch.clamp(((css.max() * 0) + 1), min=1e-12)

    def calc_spm_base_voltage(self, css_n, css_p, current):
        css_n = css_n.clamp(1.0, self.p.c_s_n_max * 0.999)
        css_p = css_p.clamp(1.0, self.p.c_s_p_max * 0.999)
        theta_n = css_n / self.p.c_s_n_max
        theta_p = css_p / self.p.c_s_p_max
        ce_ref = torch.full_like(css_n, self.p.c_e)
        i_0n = self.p.k_n0 * torch.exp(torch.as_tensor(self.p.E_kn / self.p.R * (1 / self.p.T_ref - 1 / self.p.T_amb), dtype=css_n.dtype, device=css_n.device)) \
            * torch.clamp((self.p.c_s_n_max - css_n) * css_n * ce_ref, min=1e-12) ** self.p.alph
        i_0p = self.p.k_p0 * torch.exp(torch.as_tensor(self.p.E_kp / self.p.R * (1 / self.p.T_ref - 1 / self.p.T_amb), dtype=css_n.dtype, device=css_n.device)) \
            * torch.clamp((self.p.c_s_p_max - css_p) * css_p * ce_ref, min=1e-12) ** self.p.alph
        rtaf = (self.p.R * self.p.T_amb) / (self.p.alph * self.p.Faraday)
        return (rtaf * torch.arcsinh(-current / (2 * self.p.a_s_p * self.p.Area_p * self.p.L_p * i_0p))
                - rtaf * torch.arcsinh(current / (2 * self.p.a_s_n * self.p.Area_n * self.p.L_n * i_0n))
                + ref_potential_cathode(theta_p)
                - ref_potential_anode(theta_n)
                - (self.p.R_f_n / (self.p.a_s_n * self.p.L_n * self.p.Area_n)
                   + self.p.R_f_p / (self.p.a_s_p * self.p.L_p * self.p.Area_p)) * current)

    def calc_voltage(self, css_n, css_p, c_e, current, disable_electrolyte_ohmic=False, disable_electrolyte_concentration=False):
        original_shape = css_n.shape
        css_n_flat = css_n.reshape(-1, 1).clamp(1.0, self.p.c_s_n_max * 0.999)
        css_p_flat = css_p.reshape(-1, 1).clamp(1.0, self.p.c_s_p_max * 0.999)
        current_flat = current.reshape(-1, 1)

        if c_e.dim() == 2:
            c_e_flat = c_e
        elif c_e.dim() == 3:
            c_e_flat = c_e.permute(0, 2, 1).reshape(-1, c_e.shape[1])
        else:
            raise ValueError('c_e must be 2D or 3D.')

        ce0n, cens, cesp, ce0p, _ = electrolyte_boundary_concentrations(c_e_flat, self.p)
        cen_bar, ces_bar, cep_bar = electrolyte_region_means(c_e_flat, self.p)

        theta_n = css_n_flat / self.p.c_s_n_max
        theta_p = css_p_flat / self.p.c_s_p_max
        unref = ref_potential_anode(theta_n)
        upref = ref_potential_cathode(theta_p)

        arrh_kn = torch.exp(torch.as_tensor(self.p.E_kn / self.p.R * (1 / self.p.T_ref - 1 / self.p.T_amb), dtype=css_n_flat.dtype, device=css_n_flat.device))
        arrh_kp = torch.exp(torch.as_tensor(self.p.E_kp / self.p.R * (1 / self.p.T_ref - 1 / self.p.T_amb), dtype=css_n_flat.dtype, device=css_n_flat.device))
        i_0n = self.p.k_n0 * arrh_kn * torch.clamp((self.p.c_s_n_max - css_n_flat) * css_n_flat * ce0n.clamp_min(1.0), min=1e-12) ** self.p.alph
        i_0p = self.p.k_p0 * arrh_kp * torch.clamp((self.p.c_s_p_max - css_p_flat) * css_p_flat * ce0p.clamp_min(1.0), min=1e-12) ** self.p.alph

        rtaf = (self.p.R * self.p.T_amb) / (self.p.alph * self.p.Faraday)
        v_spm = (rtaf * torch.arcsinh(-current_flat / (2 * self.p.a_s_p * self.p.Area_p * self.p.L_p * i_0p))
                 - rtaf * torch.arcsinh(current_flat / (2 * self.p.a_s_n * self.p.Area_n * self.p.L_n * i_0n))
                 + upref - unref
                 - (self.p.R_f_n / (self.p.a_s_n * self.p.L_n * self.p.Area_n)
                    + self.p.R_f_p / (self.p.a_s_p * self.p.L_p * self.p.Area_p)) * current_flat)

        kap_n_eff = electrolyte_conductivity(cen_bar, self.p) * (self.p.epsilon_e_n ** self.p.brug)
        kap_s_eff = electrolyte_conductivity(ces_bar, self.p) * (self.p.epsilon_e_s ** self.p.brug)
        kap_p_eff = electrolyte_conductivity(cep_bar, self.p) * (self.p.epsilon_e_p ** self.p.brug)
        v_ohmic = (self.p.L_n / (2 * kap_n_eff) + self.p.L_s / kap_s_eff + self.p.L_p / (2 * kap_p_eff)) * current_flat

        if self.cfg.get('use_electrolyte_activity', False):
            dfca_n = electrolyte_activity(cen_bar, self.p)
            dfca_s = electrolyte_activity(ces_bar, self.p)
            dfca_p = electrolyte_activity(cep_bar, self.p)
        else:
            dfca_n = torch.zeros_like(cen_bar)
            dfca_s = torch.zeros_like(ces_bar)
            dfca_p = torch.zeros_like(cep_bar)

        v_conc = (2 * self.p.R * self.p.T_amb / self.p.Faraday) * (
            (1 + dfca_n) * (torch.log(cens.clamp_min(1.0)) - torch.log(ce0n.clamp_min(1.0)))
            + (1 + dfca_s) * (torch.log(cesp.clamp_min(1.0)) - torch.log(cens.clamp_min(1.0)))
            + (1 + dfca_p) * (torch.log(ce0p.clamp_min(1.0)) - torch.log(cesp.clamp_min(1.0)))
        )

        if disable_electrolyte_ohmic:
            v_ohmic = torch.zeros_like(v_ohmic)
        if disable_electrolyte_concentration:
            v_conc = torch.zeros_like(v_conc)

        voltage = (v_spm + v_ohmic + v_conc).reshape(original_shape)
        return voltage