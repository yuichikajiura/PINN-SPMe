import os
import time

import numpy as np
import pandas as pd
import torch
import torch.optim as optim

import helper_func as hf
import losses_spme
from pinn_spme_network import PINNSPMeNetwork
from spme_model import SPMeModel


def _create_windows(array, window, lengths):
    array = np.asarray(array)
    original_is_vector = array.ndim == 1
    if original_is_vector:
        array = array[:, None]

    windows = []
    start = 0
    for length in lengths:
        for idx in range(length - window + 1):
            windows.append(array[start + idx:start + idx + window])
        start += length
    windows = np.stack(windows, axis=0)
    if original_is_vector:
        return windows[:, :, 0]
    return windows


def _average_chunks(sequence, h):
    batch_size, length = sequence.shape
    sequence = sequence[:, :length - (length % h)]
    return sequence.reshape(batch_size, -1, h).mean(dim=-1)


def _sample_chunks(sequence, h):
    idx = torch.arange(h - 1, sequence.shape[1], h, device=sequence.device)
    return sequence.index_select(1, idx)


def _sample_state_chunks(sequence, h):
    idx = torch.arange(h - 1, sequence.shape[1], h, device=sequence.device)
    return sequence.index_select(1, idx)


def _simulate_spme_profile(current_profile, model, device):
    dtype = torch.float32
    x = model.initial_state(1, device=device, dtype=dtype)
    n_steps = len(current_profile)
    x_hist = torch.zeros(n_steps, model.p.state_dim, device=device, dtype=dtype)
    vt_hist = torch.zeros(n_steps, device=device, dtype=dtype)

    with torch.no_grad():
        for idx in range(n_steps):
            current = torch.tensor([[float(current_profile[idx])]], device=device, dtype=dtype)
            x_hist[idx] = x.squeeze(0)
            c_n, c_p = model.calc_css_and_cs0(x, current)
            _, c_e, _ = model.unpack_state(x)
            vt_hist[idx] = model.calc_voltage(c_n[:, -1], c_p[:, -1], c_e, current).squeeze()
            x = model.step(x, current)

    return x_hist.cpu().numpy(), vt_hist.cpu().numpy()


def _build_synthetic_dataset(cfg, device, p):
    base_model = SPMeModel(p, cfg).to(device)

    train_data, train_lengths = hf.load_data_spmfdm(cfg['train_data_type'], cell=cfg.get('current_profile_cell', 1))
    val_data, val_lengths = hf.load_data_spmfdm(cfg['val_data_type'], cell=cfg.get('current_profile_cell', 1))

    x_train, vt_train = _simulate_spme_profile(train_data['Current(A)'].to_numpy(), base_model, device)
    x_val, vt_val = _simulate_spme_profile(val_data['Current(A)'].to_numpy(), base_model, device)

    return {
        'train': {
            'current': train_data['Current(A)'].to_numpy(),
            'voltage': vt_train,
            'state': x_train,
            'lengths': train_lengths,
        },
        'val': {
            'current': val_data['Current(A)'].to_numpy(),
            'voltage': vt_val,
            'state': x_val,
            'lengths': val_lengths,
        },
    }


def _prepare_dataset(split_data, cfg, p, device):
    k = cfg['k']
    h = cfg['h']
    lengths = split_data['lengths']

    i_windows = _create_windows(split_data['current'], 2 * k, lengths)
    v_windows = _create_windows(split_data['voltage'], 2 * k, lengths)
    x_windows = _create_windows(split_data['state'], 2 * k, lengths)

    i_windows = torch.tensor(i_windows, dtype=torch.float32, device=device)
    v_windows = torch.tensor(v_windows, dtype=torch.float32, device=device)
    x_windows = torch.tensor(x_windows, dtype=torch.float32, device=device)

    u = torch.zeros(i_windows.shape[0], k, p.input_size, device=device)
    u[:, :, 0] = i_windows[:, :k]
    u[:, :, 1] = v_windows[:, :k]

    ub = torch.tensor([
        cfg['OneC'] * cfg['max_Crate'],
        cfg['V_upper'],
    ], dtype=torch.float32, device=device)
    lb = torch.tensor([
        -cfg['OneC'] * cfg['max_Crate'],
        cfg['V_lower'],
    ], dtype=torch.float32, device=device)
    u = (u - lb) / (ub - lb)

    i_future = i_windows[:, k:]
    i_future_ave = _average_chunks(i_future, h)
    i_future_sampled = torch.cat([i_windows[:, k - 1:k], _sample_chunks(i_future, h)], dim=1)
    v_future_sampled = torch.cat([v_windows[:, k - 1:k], _sample_chunks(v_windows[:, k:], h)], dim=1)

    x_future_sampled = torch.cat([
        x_windows[:, k - 1:k, :],
        _sample_state_chunks(x_windows[:, k:, :], h),
    ], dim=1)

    return {
        'u': u,
        'i_future_ave': i_future_ave,
        'i_future_sampled': i_future_sampled,
        'v_future_sampled': v_future_sampled,
        'x_future_sampled': x_future_sampled,
    }


def _evaluate(network, model, dataset, cfg, p):
    with torch.no_grad():
        x0_pred = network(dataset['u'])
        x_roll_future = model(x0_pred, dataset['i_future_ave'])
        x_roll = torch.cat([x0_pred.unsqueeze(-1), x_roll_future], dim=-1)
        c_s_n_seq, c_e_seq, c_s_p_seq = model.unpack_state(x_roll)
        c_n_seq, c_p_seq = model.calc_css_and_cs0_seq(x_roll, dataset['i_future_sampled'])
        vt_pred = model.calc_voltage(c_n_seq[:, -1, :], c_p_seq[:, -1, :], c_e_seq, dataset['i_future_sampled'])

        loss_v = losses_spme.voltage_loss(vt_pred, dataset['v_future_sampled'])
        loss_li_s = losses_spme.solid_lithium_loss(model, c_n_seq, c_p_seq, p.nLi_s)
        loss_li_e = losses_spme.electrolyte_lithium_loss(c_e_seq, p, p.nLi_e)
        loss_bounds = losses_spme.bounds_loss(c_n_seq, c_e_seq, c_p_seq, p)
        loss_ce_int = losses_spme.electrolyte_interface_optional_loss(c_e_seq, p)
        loss = (cfg['w_v'] * loss_v + cfg['w_li_s'] * loss_li_s + cfg['w_li_e'] * loss_li_e
                + cfg['w_bounds'] * loss_bounds + cfg['w_ce_int'] * loss_ce_int)

        if cfg.get('supervise_states', False):
            loss_state = losses_spme.rmse_loss(x_roll.permute(0, 2, 1), dataset['x_future_sampled'])
            loss = loss + cfg.get('w_state', 0.0) * loss_state
        else:
            loss_state = torch.tensor(0.0, device=loss.device)

    return {
        'loss': loss.item(),
        'loss_v': loss_v.item(),
        'loss_li_s': loss_li_s.item(),
        'loss_li_e': loss_li_e.item(),
        'loss_bounds': loss_bounds.item(),
        'loss_state': loss_state.item(),
    }


def train(cfg, device, p):
    os.makedirs(cfg.get('save_dir', 'results'), exist_ok=True)
    start_time = time.time()

    synthetic = _build_synthetic_dataset(cfg, device, p)
    train_data = _prepare_dataset(synthetic['train'], cfg, p, device)
    val_data = _prepare_dataset(synthetic['val'], cfg, p, device)

    network = PINNSPMeNetwork(cfg, p).to(device)
    model = SPMeModel(p, cfg).to(device)
    optimizer = optim.Adam(network.parameters(), lr=cfg['lrate'])

    n_samples = train_data['u'].shape[0]
    batch_size = cfg.get('batch_size', n_samples)
    history = []
    best_val = float('inf')

    print('Start SPMe PINN training')
    for epoch in range(cfg['epochs']):
        permutation = torch.randperm(n_samples, device=device)
        epoch_loss = 0.0

        for batch_start in range(0, n_samples, batch_size):
            idx = permutation[batch_start:batch_start + batch_size]
            u_batch = train_data['u'][idx]
            i_future_ave_batch = train_data['i_future_ave'][idx]
            i_future_sampled_batch = train_data['i_future_sampled'][idx]
            v_target_batch = train_data['v_future_sampled'][idx]
            x_target_batch = train_data['x_future_sampled'][idx]

            x0_pred = network(u_batch)
            x_roll_future = model(x0_pred, i_future_ave_batch)
            x_roll = torch.cat([x0_pred.unsqueeze(-1), x_roll_future], dim=-1)

            c_s_n_seq, c_e_seq, c_s_p_seq = model.unpack_state(x_roll)
            c_n_seq, c_p_seq = model.calc_css_and_cs0_seq(x_roll, i_future_sampled_batch)
            vt_pred = model.calc_voltage(c_n_seq[:, -1, :], c_p_seq[:, -1, :], c_e_seq, i_future_sampled_batch,
                                         disable_electrolyte_ohmic=cfg.get('disable_electrolyte_ohmic', False),
                                         disable_electrolyte_concentration=cfg.get('disable_electrolyte_concentration', False))

            loss_v = losses_spme.voltage_loss(vt_pred, v_target_batch)
            loss_li_s = losses_spme.solid_lithium_loss(model, c_n_seq, c_p_seq, p.nLi_s)
            loss_li_e = losses_spme.electrolyte_lithium_loss(c_e_seq, p, p.nLi_e)
            loss_bounds = losses_spme.bounds_loss(c_n_seq, c_e_seq, c_p_seq, p)
            loss_ce_int = losses_spme.electrolyte_interface_optional_loss(c_e_seq, p)

            loss = (cfg['w_v'] * loss_v + cfg['w_li_s'] * loss_li_s + cfg['w_li_e'] * loss_li_e
                    + cfg['w_bounds'] * loss_bounds + cfg['w_ce_int'] * loss_ce_int)

            if cfg.get('supervise_states', False):
                loss_state = losses_spme.rmse_loss(x_roll.permute(0, 2, 1), x_target_batch)
                loss = loss + cfg.get('w_state', 0.0) * loss_state

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * len(idx)

        if epoch >= cfg['decay_step']:
            for group in optimizer.param_groups:
                group['lr'] *= cfg['decay_rate']

        metrics_train = _evaluate(network, model, train_data, cfg, p)
        metrics_val = _evaluate(network, model, val_data, cfg, p)
        epoch_loss /= n_samples

        history.append({
            'epoch': epoch,
            'loss': epoch_loss,
            'train_loss_v': metrics_train['loss_v'],
            'train_loss_li_s': metrics_train['loss_li_s'],
            'train_loss_li_e': metrics_train['loss_li_e'],
            'train_loss_bounds': metrics_train['loss_bounds'],
            'train_loss_state': metrics_train['loss_state'],
            'val_loss': metrics_val['loss'],
        })

        if (epoch + 1) % cfg.get('print_every', 50) == 0 or epoch == 0:
            print(f"Epoch {epoch + 1:5d} | loss {epoch_loss:.6f} | val {metrics_val['loss']:.6f} | "
                  f"V {metrics_train['loss_v']:.6f} | Li_s {metrics_train['loss_li_s']:.6f} | "
                  f"Li_e {metrics_train['loss_li_e']:.6f}")

        if metrics_val['loss'] < best_val:
            best_val = metrics_val['loss']
            torch.save(network.state_dict(), os.path.join(cfg.get('save_dir', 'results'), cfg['network_save_name']))

    pd.DataFrame(history).to_csv(os.path.join(cfg.get('save_dir', 'results'), cfg['history_save_name']), index=False)
    elapsed = time.time() - start_time
    print(f'Training time: {elapsed:.2f} sec')