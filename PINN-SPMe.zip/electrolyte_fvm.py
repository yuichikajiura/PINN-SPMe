import torch


def _harmonic_mean(a, b, eps=1e-12):
    return 2.0 * a * b / (a + b + eps)


def electrolyte_diffusivity(c_e, p):
    arrh = torch.exp(torch.as_tensor(p.E_De / p.R * (1 / p.T_ref - 1 / p.T_amb), dtype=c_e.dtype, device=c_e.device))
    c_scaled = c_e / 1000.0
    return (8.794e-11 * c_scaled ** 2 - 3.972e-10 * c_scaled + 4.862e-10) * arrh


def electrolyte_conductivity(c_e, p):
    arrh = torch.exp(torch.as_tensor(p.E_kappa_e / p.R * (1 / p.T_ref - 1 / p.T_amb), dtype=c_e.dtype, device=c_e.device))
    c_scaled = c_e / 1000.0
    return (0.1297 * c_scaled ** 3 - 2.51 * c_scaled ** 1.5 + 3.329 * c_scaled) * arrh


def electrolyte_activity(c_e, p):
    v00 = 0.601
    v10 = -0.24
    v30 = 0.982
    v31 = -0.0052
    c_scaled = c_e / 1000.0
    return ((v00 + v10 * c_scaled.sqrt() + v30 * (1 + v31 * (p.T_amb - p.T_ref)) * c_scaled ** 1.5)
            / (1 - p.t_plus)) - 1


def split_electrolyte_regions(c_e, p):
    n_end = p.Nxn - 1
    s_end = n_end + p.Nxs - 1
    c_en = c_e[..., :n_end]
    c_es = c_e[..., n_end:s_end]
    c_ep = c_e[..., s_end:]
    return c_en, c_es, c_ep


def electrolyte_rhs(c_e, jn, jp, p):
    if c_e.dim() != 2:
        raise ValueError('electrolyte_rhs expects c_e with shape [batch, n_ce].')

    batch_size = c_e.shape[0]
    c_en, c_es, c_ep = split_electrolyte_regions(c_e, p)

    dx_n = p.L_n * p.delta_x_n
    dx_s = p.L_s * p.delta_x_s
    dx_p = p.L_p * p.delta_x_p

    D_en_eff = electrolyte_diffusivity(c_en, p) * (p.epsilon_e_n ** (p.brug - 1))
    D_es_eff = electrolyte_diffusivity(c_es, p) * (p.epsilon_e_s ** (p.brug - 1))
    D_ep_eff = electrolyte_diffusivity(c_ep, p) * (p.epsilon_e_p ** (p.brug - 1))

    src_n = ((1 - p.t_plus) * p.a_s_n / p.epsilon_e_n) * jn.expand(batch_size, c_en.shape[1])
    src_s = torch.zeros_like(c_es)
    src_p = ((1 - p.t_plus) * p.a_s_p / p.epsilon_e_p) * jp.expand(batch_size, c_ep.shape[1])

    F_n = torch.zeros(batch_size, max(c_en.shape[1] - 1, 0), dtype=c_e.dtype, device=c_e.device)
    F_s = torch.zeros(batch_size, max(c_es.shape[1] - 1, 0), dtype=c_e.dtype, device=c_e.device)
    F_p = torch.zeros(batch_size, max(c_ep.shape[1] - 1, 0), dtype=c_e.dtype, device=c_e.device)

    if c_en.shape[1] > 1:
        F_n = -_harmonic_mean(D_en_eff[:, :-1], D_en_eff[:, 1:]) * (c_en[:, 1:] - c_en[:, :-1]) / dx_n
    if c_es.shape[1] > 1:
        F_s = -_harmonic_mean(D_es_eff[:, :-1], D_es_eff[:, 1:]) * (c_es[:, 1:] - c_es[:, :-1]) / dx_s
    if c_ep.shape[1] > 1:
        F_p = -_harmonic_mean(D_ep_eff[:, :-1], D_ep_eff[:, 1:]) * (c_ep[:, 1:] - c_ep[:, :-1]) / dx_p

    F_ns = -_harmonic_mean(D_en_eff[:, -1:], D_es_eff[:, :1]) * (c_es[:, :1] - c_en[:, -1:]) / (0.5 * dx_n + 0.5 * dx_s)
    F_sp = -_harmonic_mean(D_es_eff[:, -1:], D_ep_eff[:, :1]) * (c_ep[:, :1] - c_es[:, -1:]) / (0.5 * dx_s + 0.5 * dx_p)

    c_en_dot = torch.zeros_like(c_en)
    c_es_dot = torch.zeros_like(c_es)
    c_ep_dot = torch.zeros_like(c_ep)

    for idx in range(c_en.shape[1]):
        f_left = torch.zeros(batch_size, 1, dtype=c_e.dtype, device=c_e.device) if idx == 0 else F_n[:, idx - 1:idx]
        f_right = F_ns if idx == c_en.shape[1] - 1 else F_n[:, idx:idx + 1]
        c_en_dot[:, idx:idx + 1] = (f_left - f_right) / (p.epsilon_e_n * dx_n) + src_n[:, idx:idx + 1]

    for idx in range(c_es.shape[1]):
        f_left = F_ns if idx == 0 else F_s[:, idx - 1:idx]
        f_right = F_sp if idx == c_es.shape[1] - 1 else F_s[:, idx:idx + 1]
        c_es_dot[:, idx:idx + 1] = (f_left - f_right) / (p.epsilon_e_s * dx_s) + src_s[:, idx:idx + 1]

    for idx in range(c_ep.shape[1]):
        f_left = F_sp if idx == 0 else F_p[:, idx - 1:idx]
        f_right = torch.zeros(batch_size, 1, dtype=c_e.dtype, device=c_e.device) if idx == c_ep.shape[1] - 1 else F_p[:, idx:idx + 1]
        c_ep_dot[:, idx:idx + 1] = (f_left - f_right) / (p.epsilon_e_p * dx_p) + src_p[:, idx:idx + 1]

    return torch.cat([c_en_dot, c_es_dot, c_ep_dot], dim=1)


def reconstruct_full_concentration(c_e, p):
    if c_e.dim() != 2:
        raise ValueError('reconstruct_full_concentration expects c_e with shape [batch, n_ce].')

    c_en, c_es, c_ep = split_electrolyte_regions(c_e, p)
    dx_n = p.L_n * p.delta_x_n
    dx_s = p.L_s * p.delta_x_s
    dx_p = p.L_p * p.delta_x_p

    D_en_eff = electrolyte_diffusivity(c_en, p) * (p.epsilon_e_n ** (p.brug - 1))
    D_es_eff = electrolyte_diffusivity(c_es, p) * (p.epsilon_e_s ** (p.brug - 1))
    D_ep_eff = electrolyte_diffusivity(c_ep, p) * (p.epsilon_e_p ** (p.brug - 1))

    g_ns_l = D_en_eff[:, -1:] / (0.5 * dx_n)
    g_ns_r = D_es_eff[:, :1] / (0.5 * dx_s)
    c_ns = (g_ns_l * c_en[:, -1:] + g_ns_r * c_es[:, :1]) / (g_ns_l + g_ns_r + 1e-12)

    g_sp_l = D_es_eff[:, -1:] / (0.5 * dx_s)
    g_sp_r = D_ep_eff[:, :1] / (0.5 * dx_p)
    c_sp = (g_sp_l * c_es[:, -1:] + g_sp_r * c_ep[:, :1]) / (g_sp_l + g_sp_r + 1e-12)

    ce0n = c_en[:, :1]
    ce0p = c_ep[:, -1:]
    return torch.cat([ce0n, c_en, c_ns, c_es, c_sp, c_ep, ce0p], dim=1)


def electrolyte_boundary_concentrations(c_e, p):
    c_ex = reconstruct_full_concentration(c_e, p)
    ce0n = c_ex[:, :1]
    cens = c_ex[:, p.Nxn:p.Nxn + 1]
    cesp = c_ex[:, p.Nxn + p.Nxs:p.Nxn + p.Nxs + 1]
    ce0p = c_ex[:, -1:]
    return ce0n, cens, cesp, ce0p, c_ex


def electrolyte_region_means(c_e, p):
    c_en, c_es, c_ep = split_electrolyte_regions(c_e, p)
    return c_en.mean(dim=1, keepdim=True), c_es.mean(dim=1, keepdim=True), c_ep.mean(dim=1, keepdim=True)


def electrolyte_lithium_inventory(c_e, p):
    c_en, c_es, c_ep = split_electrolyte_regions(c_e, p)
    dx_n = p.L_n * p.delta_x_n
    dx_s = p.L_s * p.delta_x_s
    dx_p = p.L_p * p.delta_x_p
    n_li_n = p.A_e * p.epsilon_e_n * dx_n * c_en.sum(dim=-1)
    n_li_s = p.A_e * p.epsilon_e_s * dx_s * c_es.sum(dim=-1)
    n_li_p = p.A_e * p.epsilon_e_p * dx_p * c_ep.sum(dim=-1)
    return n_li_n + n_li_s + n_li_p